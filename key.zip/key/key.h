
 /***************************************************************************/
 /*                                                                         */
 /*       Copyright (C) 2003 Daniel Sleator and David Temperley             */
 /*           See http://www.link.cs.cmu.edu/music-analysis                 */
 /*        for information about commercial use of this system              */
 /*                                                                         */
 /***************************************************************************/ 

#include <stdio.h>

extern FILE *in_file;
extern FILE *out_file;

extern int display_command;
extern int numnotes, numbeats, numchords, num_sbeats;
extern int total_duration;
extern int final_timepoint;
extern int firstbeat;
extern int harmonic_input;
extern double default_profile_value;
extern double major_profile[12]; /* In line of fifths order */
extern double minor_profile[12];
extern int segment_beat_level;
extern int beat_printout_level;
extern float change_penalty;
extern int verbosity;
extern int romnums;
extern int romnum_type;
extern int running;
extern int npc_or_tpc_profile;
extern int scoring_mode;
extern double seglength;
typedef struct note_struct {
  int ontime;
  int offtime;
  int duration;
  int pitch;
  int tpc;
} blah;

extern struct note_struct note[10000];

typedef struct chord_struct {
  int ontime;
  int offtime;
  int duration;
  int root;
  int key;
  int function;
  int romnum;
  int mode;       /* major =1, minor =2, unspecified = 0 */
  int ext;        /* seventh = 1, no seventh = 0 */
  int inversion;  /* 0 = root, 1 = first, 2 = second, 3 = third */
  int fifth;      /* 1 = perfect fifth, 2 = diminished, 3 = unspecified */
  int beatlevel;
} blar;

extern struct chord_struct ichord[5000];      /* input chords */
extern struct chord_struct chord[2000];       

struct beat_struct {
  int time;
  int level;
};
extern struct beat_struct beat[5000];

struct sbeat_struct {
  int time;
};
extern struct sbeat_struct sbeat[1000];

extern int pc_dur[12];
extern int pc_tally[500];

extern char letter[7];

extern double key_profile[56][28];

struct segment_struct {
    int start;
    int end;
    struct note_struct snote[100];
    int numnotes;        /* number of notes in the segment */
    double average_dur;         /* average input vector value (needed for K-S algorithm) */
};
extern struct segment_struct segment[500];        /* An array storing the notes in each segment. */
extern int segtotal;              /* total number of segments - 1 */

extern int seg_prof[500][28];
extern double key_score[500][56];
extern double total_prob[500];

extern double analysis[500][56][56];
extern int best[500][56];
extern int seg;
extern int final[500];
extern int provisional[500][500]; /* used for printing out provisional analyses at each step */

extern double final_score[500];

/* Function Prototypes */
void create_chords(void);
void create_segments(void);
void fill_segments(void);
void count_segment_notes(void);
void prepare_profiles(void);
void generate_tpc_profiles(void);
void generate_npc_profiles(void);
void match_profiles(void);
void make_first_table(void);
void make_tables(void);
void best_key_analysis(void);
void generate_chord_info(void);
void merge_functions(void);
void chords_to_romnums_kp(void);
void print_romnums_kp(void);
void chords_to_romnums_as(void);
void print_romnums_as(void);
void display_running(void);
void bad_param(char *line);
void read_parameter_file(char *filename, int file_specified);
void bad_input(int ln);
void print_keyname(int f);
void choose_best_i(void);
void display_table(void);

